(function () {
  const script = document.currentScript;
  const API = (script && script.dataset.api) || new URL(script.src).origin;
  const TITLE = (script && script.dataset.title) || "دستیار نیو لایف";
  const COLOR = (script && script.dataset.color) || "#1d4f91";
  const COLOR2 = (script && script.dataset.color2) || "#3b82c4";

  // Persian font (Vazirmatn). Falls back to Tahoma if the font host is unreachable.
  if (!document.getElementById("nlc-font")) {
    const l = document.createElement("link");
    l.id = "nlc-font"; l.rel = "stylesheet";
    l.href = API + "/static/fonts/vazirmatn.css";
    document.head.appendChild(l);
  }

  let sid = null;
  try { sid = localStorage.getItem("nl_chat_sid"); } catch (e) {}

  // ---------------------------------------------------------------------------
  // Analytics: sends visitor behaviour to <API>/track (read by dashboard.py)
  // ---------------------------------------------------------------------------
  const TRACK_URL = API + "/track";
  const SLOW_MS = 3000;
  let vid = null;
  try {
    vid = localStorage.getItem("nl_vid");
    if (!vid) {
      vid = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2);
      localStorage.setItem("nl_vid", vid);
    }
  } catch (e) { vid = vid || "t" + Date.now().toString(36) + Math.random().toString(36).slice(2); }
  const pv = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);   // one id per page load
  const queue = [];
  let activeSec = 0, totalStart = Date.now();

  function flush() {
    if (!queue.length) return;
    const body = JSON.stringify({ events: queue.splice(0, 50) });
    try { if (navigator.sendBeacon && navigator.sendBeacon(TRACK_URL, new Blob([body], { type: "text/plain" }))) return; } catch (e) {}
    try { fetch(TRACK_URL, { method: "POST", headers: { "Content-Type": "text/plain" }, body, keepalive: true }).catch(() => {}); } catch (e) {}
  }
  function track(type, target, value, detail) {
    try {
      queue.push({
        type, pv, visitor_id: vid, session_id: sid, page: location.pathname,
        target: target ? String(target).slice(0, 200) : "",
        value: value == null ? null : Number(value),
        detail: detail == null ? "" : (typeof detail === "string" ? detail : JSON.stringify(detail)).slice(0, 500),
      });
      if (queue.length >= 15) flush();
    } catch (e) {}
  }
  setInterval(flush, 5000);

  // time on site: count only seconds where the tab is visible
  setInterval(() => { if (document.visibilityState === "visible") activeSec += 1; }, 1000);
  setInterval(() => { track("heartbeat", "", activeSec, Math.round((Date.now() - totalStart) / 1000)); }, 15000);
  function leave() {
    track("page_exit", "", activeSec, Math.round((Date.now() - totalStart) / 1000));
    flush();
  }
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") leave(); });
  window.addEventListener("pagehide", leave);

  track("page_view", "", null, {
    ref: document.referrer ? new URL(document.referrer).hostname : "",
    w: window.innerWidth, h: window.innerHeight,
    device: /Mobi|Android|iPhone/i.test(navigator.userAgent) ? "mobile" : "desktop",
  });

  // page load timing + slow resources
  window.addEventListener("load", () => {
    setTimeout(() => {
      try {
        const n = performance.getEntriesByType("navigation")[0];
        if (n) track("perf", "page_load", Math.round(n.loadEventEnd), {
          ttfb: Math.round(n.responseStart), dcl: Math.round(n.domContentLoadedEventEnd), load: Math.round(n.loadEventEnd),
        });
      } catch (e) {}
    }, 0);
  });
  try {
    new PerformanceObserver((list) => {
      list.getEntries().forEach((r) => {
        if (r.duration > SLOW_MS && r.name.indexOf(TRACK_URL) !== 0) track("slow_resource", r.name.split("?")[0], Math.round(r.duration));
      });
    }).observe({ type: "resource", buffered: true });
  } catch (e) {}

  // clicks (what they pressed) + rage clicks (repeated clicking = something is broken or slow)
  let lastEl = null, lastT = 0, burst = 0;
  document.addEventListener("click", (ev) => {
    try {
      const el = ev.target.closest ? ev.target.closest("a,button,input,select,textarea,summary,[role=button],[data-track]") : null;
      const node = el || ev.target;
      const label = ((node.getAttribute && node.getAttribute("aria-label")) || node.innerText || node.value || node.placeholder || "").toString().replace(/\s+/g, " ").trim().slice(0, 40);
      const desc = node.tagName.toLowerCase() + (node.id ? "#" + node.id : "") + (label ? ' "' + label + '"' : "");
      if (el) track("click", desc, null, node.href || "");
      const now = Date.now();
      if (node === lastEl && now - lastT < 1000) burst++; else burst = 1;
      lastEl = node; lastT = now;
      if (burst === 3) track("rage_click", desc);
    } catch (e) {}
  }, true);

  // scroll depth milestones
  const seenDepth = {};
  window.addEventListener("scroll", () => {
    const h = document.documentElement.scrollHeight - window.innerHeight;
    if (h <= 0) return;
    const pct = Math.round((window.scrollY / h) * 100);
    [25, 50, 75, 100].forEach((m) => { if (pct >= m && !seenDepth[m]) { seenDepth[m] = 1; track("scroll_depth", "", m); } });
  }, { passive: true });

  // JavaScript errors
  window.addEventListener("error", (e) => track("js_error", (e.filename || "").split("/").pop() + ":" + (e.lineno || ""), null, e.message));
  window.addEventListener("unhandledrejection", (e) => track("js_error", "promise", null, (e.reason && e.reason.message) || String(e.reason)));

  const css = `
  .nlc,.nlc *{box-sizing:border-box;font-family:Vazirmatn,Tahoma,"Segoe UI",sans-serif}
  .nlc-btn{position:fixed;bottom:20px;right:20px;width:60px;height:60px;border-radius:50%;border:0;
    background:linear-gradient(135deg,${COLOR},${COLOR2});color:#fff;font-size:28px;cursor:pointer;
    box-shadow:0 6px 20px rgba(0,0,0,.28);z-index:99998;transition:transform .2s}
  .nlc-btn:hover{transform:scale(1.08)}
  .nlc-box{position:fixed;bottom:92px;right:20px;width:360px;max-width:calc(100vw - 24px);height:520px;
    max-height:calc(100vh - 110px);background:#fff;border-radius:20px;display:none;flex-direction:column;
    overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.28);z-index:99999;direction:rtl}
  .nlc-box.open{display:flex;animation:nlcUp .25s ease}
  @keyframes nlcUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
  .nlc-head{background:linear-gradient(135deg,${COLOR},${COLOR2});color:#fff;padding:14px 16px;font-weight:700;
    font-size:15px;display:flex;align-items:center;gap:8px}
  .nlc-head .nlc-dot{width:9px;height:9px;border-radius:50%;background:#4ade80;box-shadow:0 0 0 3px rgba(74,222,128,.3)}
  .nlc-head .nlc-ask{font-size:12px;font-weight:500;background:rgba(255,255,255,.22);border-radius:14px;
    padding:4px 11px;margin-inline-start:auto;cursor:pointer;font-style:normal}
  .nlc-head .nlc-x{cursor:pointer;font-size:16px;opacity:.9}
  .nlc-msgs{flex:1;overflow-y:auto;padding:14px;background:#f1f6fb;display:flex;flex-direction:column;gap:10px}
  .nlc-m{max-width:88%;padding:9px 13px;border-radius:16px;line-height:1.9;font-size:14px;white-space:pre-wrap;word-wrap:break-word}
  .nlc-m.u{align-self:flex-start;background:linear-gradient(135deg,${COLOR},${COLOR2});color:#fff;border-bottom-right-radius:4px}
  .nlc-m.b{align-self:flex-end;background:#fff;color:#1f2937;border-bottom-left-radius:4px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .nlc-m.t{color:#9aa5b1;letter-spacing:3px}
  .nlc-in{display:flex;gap:8px;padding:10px 12px;border-top:1px solid #e3e8ee;background:#fff}
  .nlc-in input{flex:1;border:1px solid #d5dde6;border-radius:22px;padding:10px 15px;font-size:14px;outline:none;direction:rtl;background:#f8fafc}
  .nlc-in input:focus{border-color:${COLOR2};background:#fff}
  .nlc-in button{border:0;background:linear-gradient(135deg,${COLOR},${COLOR2});color:#fff;border-radius:22px;padding:0 18px;cursor:pointer;font-size:14px}
  .nlc-in button:disabled{opacity:.5}
  .nlc-form{align-self:stretch;background:#fff;border:1px solid #d5dde6;border-radius:16px;padding:14px;display:flex;flex-direction:column;gap:9px;box-shadow:0 2px 8px rgba(0,0,0,.06)}
  .nlc-form b{font-size:14px;color:${COLOR}}
  .nlc-form input,.nlc-form select,.nlc-form textarea{width:100%;border:1px solid #d5dde6;border-radius:12px;padding:9px 12px;font-size:14px;direction:rtl;outline:none;background:#f8fafc}
  .nlc-form input:focus,.nlc-form select:focus,.nlc-form textarea:focus{border-color:${COLOR2};background:#fff}
  .nlc-form textarea{resize:none;height:56px}
  .nlc-form .hp{position:absolute;left:-9999px;opacity:0}
  .nlc-form button{border:0;background:linear-gradient(135deg,${COLOR},${COLOR2});color:#fff;border-radius:12px;padding:11px;font-size:14px;cursor:pointer}
  .nlc-form button:disabled{opacity:.5}
  .nlc-form small{color:#6b7684;font-size:11px;line-height:1.7}
  .nlc-err{color:#c0392b;font-size:12px;min-height:14px}
  .nlc-tip{position:fixed;bottom:32px;right:92px;max-width:min(230px,calc(100vw - 120px));background:#fff;color:#1f2937;
    padding:10px 14px;border-radius:16px 16px 4px 16px;font-size:13px;line-height:1.8;direction:rtl;cursor:pointer;
    box-shadow:0 6px 24px rgba(0,0,0,.25);z-index:99997;opacity:0;transform:translateX(10px);pointer-events:none;transition:opacity .3s,transform .3s}
  .nlc-tip.show{opacity:1;transform:none;pointer-events:auto}`;
  const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);

  const root = document.createElement("div"); root.className = "nlc";
  root.innerHTML = `
    <button class="nlc-btn" aria-label="chat">💬</button>
    <div class="nlc-box">
      <div class="nlc-head"><i class="nlc-dot"></i>${TITLE}<em class="nlc-ask">درخواست مشاوره</em><span class="nlc-x">✕</span></div>
      <div class="nlc-msgs"></div>
      <div class="nlc-in"><input placeholder="پیام خود را بنویسید..." maxlength="1000"><button>ارسال</button></div>
    </div>`;
  document.body.appendChild(root);

  const btn = root.querySelector(".nlc-btn"), box = root.querySelector(".nlc-box");
  const msgs = root.querySelector(".nlc-msgs"), input = root.querySelector("input");
  const send = root.querySelector(".nlc-in button");

  function add(text, who) {
    const d = document.createElement("div");
    d.className = "nlc-m " + who; d.textContent = text;
    msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight; return d;
  }
  function saveSid(v) { if (v) { sid = v; try { localStorage.setItem("nl_chat_sid", sid); } catch (e) {} } }

  add("سلام! 👋 من دستیار کلینیک نیو لایف هستم. درباره کاشت مو، جراحی‌های زیبایی یا زیبایی بدون جراحی بپرسید.", "b");

  const tip = document.createElement("div");
  tip.className = "nlc-tip"; tip.textContent = "سلام 👋 برای اطلاعات خدمات و مشاوره، اینجا هستم";
  root.appendChild(tip);
  function openChat() { if (!box.classList.contains("open")) track("widget_open"); box.classList.add("open"); tip.classList.remove("show"); input.focus(); }
  window.NewLifeChat = { open: openChat };
  tip.onclick = openChat;
  try {
    if (!sessionStorage.getItem("nl_tip_seen")) {
      setTimeout(() => {
        if (!box.classList.contains("open")) { tip.classList.add("show"); sessionStorage.setItem("nl_tip_seen", "1"); }
      }, 5000);
      setTimeout(() => tip.classList.remove("show"), 16000);
    }
  } catch (e) {}
  btn.onclick = () => {
    if (box.classList.contains("open")) { box.classList.remove("open"); track("widget_close"); } else openChat();
    tip.classList.remove("show");
  };
  root.querySelector(".nlc-x").onclick = () => { box.classList.remove("open"); track("widget_close"); };

  let formShown = false;
  function showForm() {
    if (formShown) { msgs.scrollTop = msgs.scrollHeight; return; }
    formShown = true; track("form_shown");
    const f = document.createElement("div"); f.className = "nlc-form";
    f.innerHTML = `
      <b>ثبت مشخصات برای دریافت اطلاعات و قیمت‌ها</b>
      <input class="n" placeholder="نام و نام خانوادگی *" maxlength="80">
      <input class="p" placeholder="شماره موبایل * (مثلاً 09123456789)" inputmode="tel" maxlength="20" style="direction:ltr;text-align:right">
      <select class="s">
        <option value="hair">کاشت مو، ابرو و ریش</option>
        <option value="surgery">جراحی‌های زیبایی</option>
        <option value="nonsurgical">زیبایی بدون جراحی</option>
        <option value="other">سایر / نمی‌دانم</option>
      </select>
      <input class="hp" name="website" tabindex="-1" autocomplete="off">
      <div class="nlc-err"></div>
      <button>ثبت و دریافت اطلاعات</button>
      <small>با ثبت درخواست، موافقت می‌کنید که کلینیک برای ارائه مشاوره با شما تماس بگیرد.</small>`;
    msgs.appendChild(f); msgs.scrollTop = msgs.scrollHeight;
    const q = (c) => f.querySelector(c), err = q(".nlc-err"), b = q("button");
    let started = false;
    f.addEventListener("focusin", () => { if (!started) { started = true; track("form_start"); } });
    b.onclick = async () => {
      err.textContent = ""; b.disabled = true;
      const t0 = performance.now();
      try {
        const r = await fetch(API + "/lead", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: q(".n").value, phone: q(".p").value, service: q(".s").value,
            website: q(".hp").value, session_id: sid, visitor_id: vid }),
        });
        const j = await r.json();
        if (!r.ok) {
          err.textContent = j.error || "خطا"; b.disabled = false;
          track("form_error", "lead", r.status, j.error || "");
          return;
        }
        track("chat_reply", "/lead", Math.round(performance.now() - t0));
        f.remove(); formShown = false; saveSid(j.session_id);
        add(j.message || "✅ درخواست شما ثبت شد. همکاران ما به‌زودی با شما تماس می‌گیرند.", "b");
      } catch (e) { err.textContent = "اتصال برقرار نشد."; b.disabled = false; track("api_error", "/lead", null, String(e && e.message || e)); }
    };
  }
  root.querySelector(".nlc-ask").onclick = showForm;

  async function submit() {
    const text = input.value.trim();
    if (!text) return;
    input.value = ""; add(text, "u"); send.disabled = true;
    const wait = add("● ● ●", "b t");
    const t0 = performance.now();
    try {
      const r = await fetch(API + "/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, session_id: sid, visitor_id: vid }),
      });
      const j = await r.json();
      const ms = Math.round(performance.now() - t0);
      wait.className = "nlc-m b";
      wait.textContent = j.reply || j.error || "خطا";
      saveSid(j.session_id);
      if (r.ok) track("chat_reply", "/chat", ms);
      else track("api_error", "/chat", r.status, (j.error || "") + " | " + ms + "ms");
      if (j.show_form) showForm();
    } catch (e) {
      wait.className = "nlc-m b"; wait.textContent = "اتصال برقرار نشد.";
      track("api_error", "/chat", null, "network: " + String(e && e.message || e));
    }
    send.disabled = false; msgs.scrollTop = msgs.scrollHeight;
  }
  send.onclick = submit;
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
})();
