"""Streamlit dashboard for the New Life clinic chatbot  (dark + gold, Vazirmatn font).

Run:   streamlit run dashboard.py
Needs: DASHBOARD_PASSWORD (environment variable, .env or .streamlit/secrets.toml)
Fonts: static/fonts/Vazirmatn-*.woff2 (already in the chatbot project)

Reads  leads.csv     (name + phone, written by app.py)
and    analytics.db  (events sent by widget.js -> /track, written by app.py)
from the same folder as this file.
"""
import base64
import hmac
import html
import json
import os
import re
import sqlite3
from datetime import date, timedelta
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / ".env")
DB_PATH = BASE / "analytics.db"
LEADS_PATH = BASE / "leads.csv"
FONT_DIR = BASE / "static" / "fonts"

st.set_page_config(page_title="داشبورد نیو لایف", page_icon="✦", layout="wide")

# ----------------------------------------------------------------------------- design tokens
GOLD, GOLD2, DEEP = "#e3b25a", "#f6d99a", "#b9852c"
TEXT, MUTED = "#f7efe2", "rgba(247,239,226,0.62)"
GOOD, BAD, INFO, WARN = "#4ade80", "#f87171", "#60a5fa", "#fbbf24"

CSS = """
__FONTS__
:root{--gold:#e3b25a;--gold2:#f6d99a;--deep:#b9852c;--panel:rgba(255,255,255,.045);--panel2:rgba(255,255,255,.07);
--line:rgba(227,178,90,.20);--text:#f7efe2;--muted:rgba(247,239,226,.62);--good:#4ade80;--bad:#f87171;--info:#60a5fa;--warn:#fbbf24}
html,body,.stApp{direction:rtl;color:var(--text);font-family:Vazirmatn,Tahoma,"Segoe UI",sans-serif;color-scheme:dark}
.stApp{background:radial-gradient(1100px 560px at 88% -8%,rgba(227,178,90,.14),transparent 60%),
radial-gradient(900px 520px at 0% 8%,rgba(96,165,250,.07),transparent 55%),#0e0905}
.stApp *:not([data-testid="stIconMaterial"]):not([class*="material"]){font-family:Vazirmatn,Tahoma,"Segoe UI",sans-serif !important}
[data-testid="stHeader"]{background:transparent}
[data-testid="stMainMenu"],[data-testid="stAppDeployButton"],footer,[data-testid="stDecoration"]{display:none !important}
.block-container{padding-top:1.6rem;padding-bottom:3rem;max-width:1280px}
h1,h2,h3,h4,p,label,span,div{letter-spacing:0 !important}
::-webkit-scrollbar{width:9px;height:9px}::-webkit-scrollbar-thumb{background:rgba(227,178,90,.28);border-radius:9px}
::-webkit-scrollbar-track{background:transparent}

/* sidebar */
[data-testid="stSidebar"]{background:linear-gradient(180deg,#171008,#0e0905);border-left:1px solid var(--line);border-right:0}
[data-testid="stSidebar"] *{color:var(--text)}
.side-logo{display:flex;align-items:center;gap:12px;margin:4px 0 18px}
.side-logo .lg{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;font-size:20px;color:#2a1a05;
background:linear-gradient(135deg,var(--gold2),var(--gold) 55%,var(--deep));box-shadow:0 6px 18px rgba(227,178,90,.35)}
.side-logo b{display:block;font-size:16px;font-weight:800}.side-logo small{color:var(--muted);font-size:12px}
.side-h{font-size:12px;color:var(--gold2);margin:16px 0 6px;font-weight:700;opacity:.9}

/* inputs & buttons */
div[data-baseweb="input"],div[data-baseweb="base-input"],div[data-baseweb="select"]>div,div[data-baseweb="popover"] ul{
background:#1a1209 !important;border-color:rgba(227,178,90,.25) !important;border-radius:12px !important;color:var(--text) !important}
div[data-baseweb="input"] input,div[data-baseweb="base-input"] input,[data-testid="stNumberInput"] input,[data-testid="stDateInput"] input{
background:transparent !important;color:var(--text) !important;-webkit-text-fill-color:var(--text) !important;caret-color:var(--gold)}
[data-testid="stNumberInput"] button{background:transparent !important;color:var(--gold2) !important;border-color:transparent !important}
[data-testid="stSidebar"] label p{font-size:13px;color:var(--muted)}
div[data-baseweb="input"]:focus-within,div[data-baseweb="select"]>div:focus-within{border-color:var(--gold) !important;box-shadow:0 0 0 3px rgba(227,178,90,.18) !important}
.stButton>button,.stDownloadButton>button{border-radius:12px;border:1px solid var(--line);background:var(--panel);color:var(--gold2);font-weight:500;transition:.2s}
.stButton>button:hover,.stDownloadButton>button:hover{border-color:var(--gold);background:rgba(227,178,90,.12);color:#fff;transform:translateY(-1px)}
[data-testid="stToggle"] label p,[data-testid="stCheckbox"] label p{font-size:13.5px}
[data-testid="stAlert"]{border-radius:14px;background:var(--panel);border:1px solid var(--line)}

/* tabs */
[data-baseweb="tab-list"]{gap:6px;background:var(--panel);padding:6px;border-radius:16px;border:1px solid var(--line);width:fit-content;max-width:100%;overflow-x:auto;margin-bottom:10px}
[data-baseweb="tab"]{height:40px;border-radius:12px;padding:0 16px;background:transparent}
[data-baseweb="tab"] p{color:var(--muted);font-size:14px;font-weight:500}
[data-baseweb="tab"][aria-selected="true"]{background:linear-gradient(135deg,var(--gold2),var(--gold) 55%,var(--deep)) !important;box-shadow:0 4px 14px rgba(227,178,90,.3)}
[data-baseweb="tab"][aria-selected="true"] p{color:#2a1a05 !important;font-weight:800}
[data-baseweb="tab-highlight"],[data-baseweb="tab-border"]{display:none}

/* hero */
.hero{display:flex;align-items:center;gap:16px;margin-bottom:20px}
.hero .logo{width:56px;height:56px;border-radius:18px;display:grid;place-items:center;font-size:26px;color:#2a1a05;flex:none;
background:linear-gradient(135deg,var(--gold2),var(--gold) 55%,var(--deep));box-shadow:0 10px 28px rgba(227,178,90,.35)}
.hero h1{margin:0;padding:0;font-size:28px;font-weight:800;line-height:1.5;
background:linear-gradient(100deg,var(--gold2),var(--gold) 55%,var(--deep));-webkit-background-clip:text;background-clip:text;color:transparent}
.hero p{margin:2px 0 0;color:var(--muted);font-size:13.5px}
.live{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--good);margin-inline-end:6px;box-shadow:0 0 0 0 rgba(74,222,128,.6);animation:pulse 2s infinite}
@keyframes pulse{70%{box-shadow:0 0 0 9px rgba(74,222,128,0)}100%{box-shadow:0 0 0 0 rgba(74,222,128,0)}}

/* kpi cards */
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(146px,1fr));gap:14px;margin:6px 0 18px}
.kpi{position:relative;overflow:hidden;padding:16px 16px 14px;border-radius:20px;background:linear-gradient(160deg,rgba(255,255,255,.065),rgba(255,255,255,.025));
border:1px solid var(--line);backdrop-filter:blur(8px);transition:.25s}
.kpi:hover{transform:translateY(-3px);border-color:rgba(227,178,90,.5);box-shadow:0 14px 34px rgba(0,0,0,.35)}
.kpi::after{content:"";position:absolute;inset-inline-start:-30px;top:-30px;width:110px;height:110px;border-radius:50%;background:var(--tone,var(--gold));opacity:.10;filter:blur(10px)}
.kpi .ico{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;font-size:18px;margin-bottom:10px;background:rgba(255,255,255,.07)}
.kpi .val{font-size:27px;font-weight:800;line-height:1.3;color:var(--tone,var(--gold2));font-variant-numeric:tabular-nums}
.kpi .lbl{font-size:13px;color:var(--text);opacity:.88;margin-top:2px}
.kpi .hint{font-size:11.5px;color:var(--muted);margin-top:4px;min-height:17px}

/* section titles / cards */
.sec{display:flex;align-items:center;gap:10px;margin:24px 0 10px}
.sec:before{content:"";width:5px;height:22px;border-radius:4px;background:linear-gradient(var(--gold2),var(--deep))}
.sec h3{margin:0;padding:0;font-size:17px;font-weight:700}.sec small{color:var(--muted);font-size:12.5px;margin-inline-start:4px}
.card{padding:16px 18px;border-radius:20px;background:var(--panel);border:1px solid var(--line)}
.empty{padding:34px 20px;text-align:center;color:var(--muted);border:1px dashed rgba(227,178,90,.28);border-radius:18px;background:rgba(255,255,255,.025);font-size:14px}
.empty b{display:block;font-size:26px;margin-bottom:6px}
.note{color:var(--muted);font-size:12.5px;margin:6px 2px 0}

/* tables */
.tbl-wrap{overflow:auto;border-radius:18px;border:1px solid var(--line);background:rgba(255,255,255,.03);max-height:470px}
table.tbl{width:100%;border-collapse:separate;border-spacing:0;font-size:13.5px}
.tbl th{position:sticky;top:0;z-index:1;text-align:right;padding:12px 14px;font-weight:700;font-size:12.5px;color:var(--gold2);background:#1d1409;border-bottom:1px solid var(--line);white-space:nowrap}
.tbl td{padding:11px 14px;border-bottom:1px solid rgba(255,255,255,.05);vertical-align:middle;white-space:nowrap;max-width:340px;overflow:hidden;text-overflow:ellipsis}
.tbl tr:last-child td{border-bottom:0}.tbl tbody tr:nth-child(even) td{background:rgba(255,255,255,.02)}
.tbl tbody tr:hover td{background:rgba(227,178,90,.09)}
.ph{direction:ltr;unicode-bidi:embed;display:inline-block;font-variant-numeric:tabular-nums;letter-spacing:.5px;color:var(--gold2);font-weight:500}
.dim{color:var(--muted)}.num{font-variant-numeric:tabular-nums}.nw{white-space:nowrap}
.pill{display:inline-block;padding:3px 11px;border-radius:999px;font-size:12px;font-weight:500;white-space:nowrap;border:1px solid transparent}
.p-gold{color:var(--gold2);background:rgba(227,178,90,.13);border-color:rgba(227,178,90,.3)}
.p-good{color:var(--good);background:rgba(74,222,128,.12);border-color:rgba(74,222,128,.28)}
.p-bad{color:var(--bad);background:rgba(248,113,113,.13);border-color:rgba(248,113,113,.3)}
.p-info{color:var(--info);background:rgba(96,165,250,.13);border-color:rgba(96,165,250,.3)}
.p-warn{color:var(--warn);background:rgba(251,191,36,.12);border-color:rgba(251,191,36,.3)}
.p-gray{color:var(--muted);background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.1)}

/* timeline */
.tl{position:relative;margin:6px 0 4px;padding:6px 0;max-height:520px;overflow:auto}
.tl-i{position:relative;display:flex;gap:14px;padding:0 0 14px;margin-inline-end:6px}
.tl-i:before{content:"";position:absolute;inset-inline-start:calc(140px + 14px + 5px);top:16px;bottom:-2px;width:2px;background:rgba(255,255,255,.08)}
.tl-i:last-child:before{display:none}
.tl-t{flex:none;width:140px;text-align:left;direction:ltr;white-space:nowrap;font-size:11.5px;color:var(--muted);padding-top:5px;font-variant-numeric:tabular-nums}
.tl-d{flex:none;width:12px;height:12px;margin-top:7px;border-radius:50%;background:var(--c);box-shadow:0 0 0 4px color-mix(in srgb,var(--c) 22%,transparent)}
.tl-b{flex:1;padding:8px 14px;border-radius:14px;background:var(--panel);border:1px solid rgba(255,255,255,.06);min-width:0}
.tl-b b{font-size:13.5px;font-weight:700;color:var(--c)}.tl-b span{display:block;font-size:12.5px;color:var(--text);opacity:.82;margin-top:2px;word-break:break-word}

/* funnel */
.fn{display:flex;flex-direction:column;gap:10px}
.fn-r{display:grid;grid-template-columns:128px 1fr 118px;gap:12px;align-items:center;font-size:13px}
.fn.wide .fn-r{grid-template-columns:250px 1fr 140px}
.fn-bar{height:30px;border-radius:10px;background:rgba(255,255,255,.05);overflow:hidden}
.fn-bar i{display:block;height:100%;border-radius:10px;background:linear-gradient(270deg,var(--gold2),var(--gold) 50%,var(--deep));min-width:4px}
.fn-n{text-align:left;direction:ltr;color:var(--gold2);font-weight:700;font-variant-numeric:tabular-nums}.fn-n small{color:var(--muted);font-weight:400}

.lgd{display:flex;gap:18px;flex-wrap:wrap;margin:0 4px 4px;font-size:12.5px;color:var(--muted)}.lgd i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-inline-end:7px}
/* chat bubbles */
.bub{display:flex;gap:12px;margin-bottom:12px}
.bub .av{flex:none;width:38px;height:38px;border-radius:50%;display:grid;place-items:center;font-weight:800;color:#2a1a05;background:linear-gradient(135deg,var(--gold2),var(--deep))}
.bub .bd{max-width:760px;padding:10px 15px;border-radius:18px 4px 18px 18px;background:var(--panel2);border:1px solid rgba(255,255,255,.07)}
.bub .meta{font-size:12px;color:var(--muted);margin-bottom:3px}.bub .meta b{color:var(--gold2);font-weight:700}
.bub .tx{font-size:14px;line-height:2;word-break:break-word}

/* login */
.login{text-align:center;margin:8vh 0 18px}
.login .lg{width:74px;height:74px;margin:0 auto 14px;border-radius:24px;display:grid;place-items:center;font-size:34px;color:#2a1a05;
background:linear-gradient(135deg,var(--gold2),var(--gold) 55%,var(--deep));box-shadow:0 14px 40px rgba(227,178,90,.38)}
.login h2{margin:0 0 4px;font-size:24px;font-weight:800;background:linear-gradient(100deg,var(--gold2),var(--gold));-webkit-background-clip:text;background-clip:text;color:transparent}
.login p{color:var(--muted);font-size:13.5px;margin:0}
@media(max-width:700px){.fn-r{grid-template-columns:90px 1fr 92px}.tl-t{width:96px;white-space:normal}.tl-i:before{inset-inline-start:calc(96px + 14px + 5px)}.hero h1{font-size:22px}}
"""


@st.cache_resource
def font_css() -> str:
    out = []
    for weight, fname in {400: "Regular", 500: "Medium", 700: "Bold", 800: "ExtraBold"}.items():
        p = FONT_DIR / f"Vazirmatn-{fname}.woff2"
        if p.exists():
            b64 = base64.b64encode(p.read_bytes()).decode()
            out.append(
                f'@font-face{{font-family:"Vazirmatn";font-weight:{weight};font-style:normal;font-display:swap;'
                f'src:url(data:font/woff2;base64,{b64}) format("woff2")}}'
            )
    return "".join(out)


st.html(f"<style>{CSS.replace('__FONTS__', font_css())}</style>")


# ----------------------------------------------------------------------------- small helpers
def esc(x) -> str:
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return ""
    return html.escape(str(x))


class Raw(str):
    """A table cell that already contains safe HTML."""


def pill(text, tone="gray") -> Raw:
    return Raw(f'<span class="pill p-{tone}">{esc(text)}</span>')


def phone_cell(p) -> Raw:
    return Raw(f'<span class="ph">{esc(p)}</span>') if p else pill("ناشناس", "gray")


def sec(title, sub=""):
    st.html(f'<div class="sec"><h3>{esc(title)}</h3>{f"<small>{esc(sub)}</small>" if sub else ""}</div>')


def empty(text, icon="✨"):
    st.html(f'<div class="empty"><b>{icon}</b>{esc(text)}</div>')


def kpi(icon, label, value, hint="", tone=GOLD2) -> str:
    v = esc(value)
    if not re.search(r"[\u0600-\u06FF]", v):
        v = f'<span dir="ltr" style="unicode-bidi:isolate">{v}</span>'
    return (f'<div class="kpi" style="--tone:{tone}"><div class="ico">{icon}</div><div class="val">{v}</div>'
            f'<div class="lbl">{esc(label)}</div><div class="hint">{esc(hint)}</div></div>')


def kpi_row(items):
    st.html('<div class="kpis">' + "".join(kpi(*i) for i in items) + "</div>")


def _cell(v) -> str:
    if isinstance(v, Raw):
        return v
    t = esc(v)
    if re.search(r"[A-Za-z]", t) and not re.search(r"[\u0600-\u06FF]", t):
        return f'<span dir="ltr" style="unicode-bidi:isolate">{t}</span>'
    return t


def html_table(rows: list, height: int = 470):
    if not rows:
        return empty("داده‌ای برای نمایش نیست.", "🗂️")
    cols = list(rows[0].keys())
    head = "".join(f"<th>{esc(c)}</th>" for c in cols)
    body = "".join(
        "<tr>" + "".join(f"<td>{_cell(v)}</td>" for v in r.values()) + "</tr>" for r in rows
    )
    st.html(f'<div class="tbl-wrap" style="max-height:{height}px"><table class="tbl"><thead><tr>{head}</tr></thead>'
            f"<tbody>{body}</tbody></table></div>")


# ----------------------------------------------------------------------------- Jalali dates
def g2j(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + 365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100 + (gy2 + 399) // 400 + gd + g_d_m[gm - 1]
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm, jd = 1 + days // 31, 1 + days % 31
    else:
        jm, jd = 7 + (days - 186) // 30, 1 + (days - 186) % 30
    return jy, jm, jd


def fmt_d(d, short=False) -> str:
    if d is None or pd.isna(d):
        return "-"
    if not st.session_state.get("jalali", True):
        return f"{d:%m-%d}" if short else f"{d:%Y-%m-%d}"
    jy, jm, jd = g2j(d.year, d.month, d.day)
    return f"{jm:02d}/{jd:02d}" if short else f"{jy}/{jm:02d}/{jd:02d}"


def fmt_dt(ts, secs=False) -> str:
    if ts is None or pd.isna(ts):
        return "-"
    return f"{fmt_d(ts)}  {ts:%H:%M:%S}" if secs else f"{fmt_d(ts)}  {ts:%H:%M}"


def fmt_dur(sec) -> str:
    if sec is None or pd.isna(sec):
        return "-"
    m, s = divmod(int(sec), 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ----------------------------------------------------------------------------- login
def get_password() -> str:
    try:
        if "DASHBOARD_PASSWORD" in st.secrets:
            return str(st.secrets["DASHBOARD_PASSWORD"])
    except Exception:
        pass
    return os.getenv("DASHBOARD_PASSWORD", "")


def check_login() -> bool:
    if st.session_state.get("auth"):
        return True
    _, mid, _ = st.columns([1, 1.15, 1])
    with mid:
        st.html('<div class="login"><div class="lg">✦</div><h2>داشبورد کلینیک نیو لایف</h2><p>برای مشاهده آمار، وارد شوید</p></div>')
        expected = get_password()
        if not expected:
            st.error("رمز داشبورد تنظیم نشده است. در فایل .env خط DASHBOARD_PASSWORD=رمز-دلخواه را اضافه کنید.")
            return False
        pwd = st.text_input("رمز عبور", type="password", placeholder="رمز عبور را وارد کنید")
        if pwd:
            if hmac.compare_digest(pwd.encode(), expected.encode()):
                st.session_state["auth"] = True
                st.rerun()
            else:
                st.error("رمز اشتباه است.")
    return False


if not check_login():
    st.stop()

# ----------------------------------------------------------------------------- labels / categories
EVENT_COLS = ["id", "ts", "visitor_id", "session_id", "pv", "source", "type",
              "page", "target", "value", "detail", "ip", "ua"]
PROBLEM_TYPES = {"js_error", "api_error", "server_error", "rage_click", "form_error", "slow_resource"}
LABELS = {
    "page_view": "ورود به صفحه", "page_exit": "خروج از صفحه", "click": "کلیک", "rage_click": "کلیک‌های پشت‌سرهم",
    "scroll_depth": "اسکرول", "widget_open": "باز کردن چت", "widget_close": "بستن چت", "chat_message": "پیام به چت‌بات",
    "chat_reply": "دریافت پاسخ", "server_latency": "زمان پردازش مدل", "form_shown": "نمایش فرم ثبت‌نام",
    "form_start": "شروع پر کردن فرم", "form_error": "خطا در فرم", "lead_submitted": "ثبت شماره",
    "api_error": "خطای اتصال/API", "server_error": "خطای سرور", "js_error": "خطای جاوااسکریپت",
    "perf": "سرعت بارگذاری", "slow_resource": "فایل کند",
}
COLOR = {  # timeline colour per event type
    "page_view": INFO, "page_exit": "#94a3b8", "scroll_depth": "#94a3b8", "click": GOLD,
    "widget_open": "#a78bfa", "widget_close": "#a78bfa", "chat_message": "#a78bfa", "chat_reply": "#a78bfa",
    "server_latency": "#a78bfa", "form_shown": GOOD, "form_start": GOOD, "lead_submitted": GOOD, "perf": WARN,
}
KIND = {"a": "لینک", "button": "دکمه", "input": "فیلد", "select": "لیست", "textarea": "کادر متن", "summary": "منو"}


def pretty_target(t) -> str:
    """'button#x "درخواست مشاوره"'  ->  'دکمه «درخواست مشاوره»'"""
    t = "" if t is None or (isinstance(t, float) and pd.isna(t)) else str(t)
    m = re.match(r'^(\w+)(#\S+)?\s*(?:"(.*)")?$', t)
    if not m:
        return t
    kind, ident, label = KIND.get(m.group(1), m.group(1)), m.group(2) or "", m.group(3) or ""
    return f"{kind} «{label}»" if label else f"{kind} {ident}".strip()


# ----------------------------------------------------------------------------- data
@st.cache_data(ttl=10)
def load_events() -> pd.DataFrame:
    if not DB_PATH.exists():
        return pd.DataFrame(columns=EVENT_COLS)
    con = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, timeout=10)
    try:
        df = pd.read_sql_query("SELECT * FROM events ORDER BY id", con)
    finally:
        con.close()
    df["ts"] = pd.to_datetime(df["ts"], errors="coerce")
    return df


@st.cache_data(ttl=10)
def load_leads() -> pd.DataFrame:
    cols = ["time", "name", "phone", "service", "note", "session_id", "ip"]
    if not LEADS_PATH.exists():
        return pd.DataFrame(columns=cols)
    df = pd.read_csv(LEADS_PATH, dtype=str, encoding="utf-8-sig").fillna("")
    df["time"] = pd.to_datetime(df["time"], errors="coerce")
    return df


def parse_detail(s):
    try:
        d = json.loads(s)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def prepare(ev: pd.DataFrame, leads: pd.DataFrame):
    """Link events <-> visitors <-> leads (phone numbers)."""
    ev = ev.copy()
    pair = ev.dropna(subset=["visitor_id", "session_id"]).drop_duplicates("session_id")
    sid2vid = dict(zip(pair["session_id"], pair["visitor_id"]))
    ev["vid"] = ev["visitor_id"].fillna(ev["session_id"].map(sid2vid))
    ev["vid"] = ev["vid"].fillna("session:" + ev["session_id"].fillna("?"))
    leads = leads.copy()
    leads["vid"] = leads["session_id"].map(sid2vid).fillna("session:" + leads["session_id"])
    vid2lead = leads.sort_values("time").drop_duplicates("vid", keep="last").set_index("vid")
    return ev, leads, vid2lead


def visitor_table(ev: pd.DataFrame, vid2lead: pd.DataFrame) -> pd.DataFrame:
    if ev.empty:
        return pd.DataFrame()
    g = ev.groupby("vid")
    t = pd.DataFrame({
        "first_seen": g["ts"].min(), "last_seen": g["ts"].max(),
        "page_views": g["type"].apply(lambda s: (s == "page_view").sum()),
        "clicks": g["type"].apply(lambda s: (s == "click").sum()),
        "messages": g["type"].apply(lambda s: (s == "chat_message").sum()),
        "problems": g["type"].apply(lambda s: s.isin(PROBLEM_TYPES).sum()),
    })
    hb = ev[ev["type"].isin(["heartbeat", "page_exit"]) & ev["value"].notna() & ev["pv"].notna()]
    t["active_sec"] = hb.groupby(["vid", "pv"])["value"].max().groupby("vid").sum().reindex(t.index).fillna(0)
    pv = ev[ev["type"] == "page_view"].drop_duplicates("vid", keep="last").set_index("vid")["detail"]
    t["device"] = pv.map(lambda d: parse_detail(d).get("device", "")).reindex(t.index).fillna("")
    for c in ("name", "phone", "service"):
        t[c] = vid2lead[c].reindex(t.index).fillna("")
    return t.sort_values("last_seen", ascending=False)


def device_pill(d) -> Raw:
    return pill("📱 موبایل", "info") if d == "mobile" else pill("💻 دسکتاپ", "gray") if d == "desktop" else pill("-", "gray")


def problems_pill(n) -> Raw:
    return pill(f"{int(n)} مشکل", "bad") if n else pill("سالم", "good")


# ----------------------------------------------------------------------------- charts
def _style(ch, height):
    return (ch.properties(height=height, background="transparent")
            .configure_view(strokeWidth=0)
            .configure_axis(labelColor=MUTED, titleColor=MUTED, gridColor="rgba(255,255,255,0.06)",
                            domainColor="rgba(255,255,255,0.12)", tickColor="rgba(255,255,255,0.12)",
                            labelFont="Vazirmatn", titleFont="Vazirmatn", labelFontSize=12)
            .configure_legend(labelColor=TEXT, titleColor=MUTED, labelFont="Vazirmatn", titleFont="Vazirmatn", orient="bottom",
                              direction="horizontal", symbolType="circle", padding=8, labelLimit=400))


def _grad(c1, c2):
    return alt.Gradient(gradient="linear", x1=0, x2=1, y1=0, y2=0,
                        stops=[alt.GradientStop(color=c1, offset=0), alt.GradientStop(color=c2, offset=1)])


def _vgrad(c1, c2):
    return alt.Gradient(gradient="linear", x1=1, x2=1, y1=1, y2=0,
                        stops=[alt.GradientStop(color=c1, offset=0), alt.GradientStop(color=c2, offset=1)])


def show(chart):
    st.altair_chart(chart, width="stretch", theme=None)


def hbars_html(items, wide=True) -> str:
    top = max([v for _, v, _ in items] + [1])
    rows = "".join(
        f'<div class="fn-r"><div>{esc(l)}</div><div class="fn-bar"><i style="width:{v / top * 100:.1f}%"></i></div>'
        f'<div class="fn-n">{v} <small>{esc(sub)}</small></div></div>' for l, v, sub in items)
    return f'<div class="fn{" wide" if wide else ""}">{rows}</div>'


def bar_h(df, cat="label", val="count", tip="تعداد"):
    base = alt.Chart(df).encode(
        y=alt.Y(f"{cat}:N", sort="-x", title=None, axis=alt.Axis(labelLimit=240, labelPadding=8, ticks=False, domain=False)),
        x=alt.X(f"{val}:Q", title=None, axis=alt.Axis(tickMinStep=1)),
        tooltip=[alt.Tooltip(f"{cat}:N", title="مورد"), alt.Tooltip(f"{val}:Q", title=tip)])
    bars = base.mark_bar(cornerRadiusEnd=7, size=18, fill=_grad(DEEP, GOLD2))
    txt = base.mark_text(align="left", dx=6, color=TEXT, fontSize=12).encode(text=f"{val}:Q")
    show(_style(bars + txt, max(110, 36 * len(df) + 16)))


def bar_v(df, x="label", y="count", tip="تعداد", color=(DEEP, GOLD2), height=230, sort=None):
    ch = alt.Chart(df).mark_bar(cornerRadiusTopLeft=6, cornerRadiusTopRight=6, fill=_vgrad(*color)).encode(
        x=alt.X(f"{x}:N", sort=sort, title=None, axis=alt.Axis(labelAngle=0, labelOverlap="parity", ticks=False)),
        y=alt.Y(f"{y}:Q", title=None, axis=alt.Axis(tickMinStep=1)),
        tooltip=[alt.Tooltip(f"{x}:N", title="زمان"), alt.Tooltip(f"{y}:Q", title=tip)])
    show(_style(ch, height))


def line_area(df, x="label", series="series", y="value", height=240, colors=None):
    order = list(dict.fromkeys(df[x]))
    scale = alt.Scale(domain=list(colors), range=list(colors.values())) if colors else alt.Undefined
    enc = dict(x=alt.X(f"{x}:N", sort=order, title=None, axis=alt.Axis(labelAngle=0, labelOverlap="parity", ticks=False)),
               y=alt.Y(f"{y}:Q", title=None),
               color=alt.Color(f"{series}:N", scale=scale, legend=None),
               tooltip=[alt.Tooltip(f"{x}:N", title="زمان"), alt.Tooltip(f"{series}:N", title="مورد"),
                        alt.Tooltip(f"{y}:Q", title="میلی‌ثانیه", format=",.0f")])
    base = alt.Chart(df).encode(**enc)
    if colors:
        st.html('<div class="lgd">' + "".join(f'<span><i style="background:{c}"></i>{esc(n)}</span>' for n, c in colors.items()
                                              if n in set(df[series])) + "</div>")
    show(_style(base.mark_line(strokeWidth=3, interpolate="monotone") + base.mark_point(size=60, filled=True), height))


# ----------------------------------------------------------------------------- timeline / funnel / bubbles
def journey_html(ev: pd.DataFrame) -> str:
    ev = ev.fillna({"target": "", "detail": "", "page": ""})
    items = []
    for r in ev[ev["type"] != "heartbeat"].sort_values(["ts", "id"]).itertuples():
        title = LABELS.get(r.type, r.type)
        c = COLOR.get(r.type, BAD if r.type in PROBLEM_TYPES else MUTED)
        if r.type == "chat_message":
            info = r.detail
        elif r.type == "click":
            info = pretty_target(r.target)
        elif r.type == "rage_click":
            info = pretty_target(r.target)
        elif r.type == "page_exit":
            info = f"حضور فعال: {fmt_dur(r.value)}"
        elif r.type == "scroll_depth":
            info = f"تا {int(r.value)}٪ صفحه" if pd.notna(r.value) else ""
        elif r.type in ("chat_reply", "server_latency"):
            info = f"{int(r.value):,} میلی‌ثانیه" if pd.notna(r.value) else ""
        elif r.type == "perf":
            info = f"بارگذاری کامل در {int(r.value):,} میلی‌ثانیه" if pd.notna(r.value) else ""
        elif r.type == "page_view":
            d = parse_detail(r.detail)
            info = f"{r.page or '/'} · {'موبایل' if d.get('device') == 'mobile' else 'دسکتاپ'} · از: {d.get('ref') or 'ورود مستقیم'}"
        else:
            info = " · ".join(x for x in [r.target, r.detail] if x)
        items.append(
            f'<div class="tl-i" style="--c:{c}"><div class="tl-t">{esc(fmt_dt(r.ts, True))}</div><div class="tl-d"></div>'
            f'<div class="tl-b"><b>{esc(title)}</b>{f"<span>{esc(info)}</span>" if info else ""}</div></div>')
    return '<div class="tl">' + "".join(items) + "</div>"


def funnel_html(steps) -> str:
    top = max([n for _, n in steps] + [1])
    first = steps[0][1] or 1
    rows = []
    for label, n in steps:
        rows.append(f'<div class="fn-r"><div>{esc(label)}</div><div class="fn-bar"><i style="width:{n / top * 100:.1f}%"></i></div>'
                    f'<div class="fn-n">{n} <small>({n / first * 100:.0f}٪)</small></div></div>')
    return '<div class="fn">' + "".join(rows) + "</div>"


# ----------------------------------------------------------------------------- sidebar
st.sidebar.html('<div class="side-logo"><div class="lg">✦</div><div><b>نیو لایف</b><small>پایش رفتار کاربران</small></div></div>')
st.sidebar.html('<div class="side-h">بازه زمانی</div>')
today = date.today()
rng = st.sidebar.date_input("بازه", value=(today - timedelta(days=7), today), label_visibility="collapsed")
if isinstance(rng, (list, tuple)):
    d1, d2 = (rng[0], rng[1]) if len(rng) == 2 else (rng[0], rng[0])
else:
    d1 = d2 = rng
st.sidebar.html('<div class="side-h">آستانه‌ی کندی</div>')
slow_page_ms = st.sidebar.number_input("بارگذاری صفحه (میلی‌ثانیه)", 500, 30000, 3000, 500)
slow_chat_ms = st.sidebar.number_input("پاسخ چت‌بات (میلی‌ثانیه)", 1000, 60000, 8000, 1000)
st.sidebar.html('<div class="side-h">نمایش</div>')
st.sidebar.toggle("تاریخ شمسی", value=True, key="jalali")
auto = st.sidebar.toggle("به‌روزرسانی خودکار (۳۰ ثانیه)", value=False)
if st.sidebar.button("🔄  بازخوانی همین حالا", width="stretch"):
    st.cache_data.clear()
if st.sidebar.button("خروج", width="stretch"):
    st.session_state["auth"] = False
    st.rerun()


# ----------------------------------------------------------------------------- main
def render():
    ev_all, leads_all = load_events(), load_leads()
    if ev_all.empty and leads_all.empty:
        st.html('<div class="hero"><div class="logo">✦</div><div><h1>داشبورد کلینیک نیو لایف</h1></div></div>')
        empty("هنوز داده‌ای ثبت نشده. app.py و widget.js جدید را روی سرور بگذارید و چند بار سایت را باز کنید.", "🌱")
        return

    ev_all, leads_all, vid2lead = prepare(ev_all, leads_all)
    start, end = pd.Timestamp(d1), pd.Timestamp(d2) + pd.Timedelta(days=1)
    ev = ev_all[(ev_all["ts"] >= start) & (ev_all["ts"] < end)]
    leads = leads_all[(leads_all["time"] >= start) & (leads_all["time"] < end)]

    last = ev_all["ts"].max() if not ev_all.empty else None
    st.html(f'<div class="hero"><div class="logo">✦</div><div><h1>داشبورد کلینیک نیو لایف</h1>'
            f'<p>بازه: {esc(fmt_d(d1))} تا {esc(fmt_d(d2))} &nbsp;·&nbsp; <span class="live"></span>آخرین فعالیت: {esc(fmt_dt(last))}</p></div></div>')

    vt = visitor_table(ev, vid2lead)
    n_vis, n_leads = len(vt), len(leads)
    n_open = ev.loc[ev["type"] == "widget_open", "vid"].nunique()
    perf = ev[ev["type"] == "perf"]
    rtt = ev[(ev["type"] == "chat_reply") & (ev["target"] == "/chat")]
    srv = ev[ev["type"] == "server_latency"]
    slow_pages = int((perf["value"] > slow_page_ms).sum())
    slow_chats = int((rtt["value"] > slow_chat_ms).sum())
    problems = ev[ev["type"].isin(PROBLEM_TYPES)]
    n_issue = len(problems) + slow_pages + slow_chats

    kpi_row([
        ("👥", "بازدیدکننده", n_vis, f"{int((vt['device'] == 'mobile').sum()) if n_vis else 0} نفر با موبایل", INFO),
        ("📞", "شماره ثبت‌شده", n_leads, "لیدهای این بازه", GOOD),
        ("🎯", "نرخ ثبت شماره", f"{n_leads / n_vis * 100:.1f}٪" if n_vis else "-", "از کل بازدیدکنندگان", GOLD2),
        ("💬", "باز کردن چت", f"{n_open} نفر", f"{n_open / n_vis * 100:.0f}٪ بازدیدکنندگان" if n_vis else "", "#a78bfa"),
        ("⏱️", "میانگین حضور فعال", fmt_dur(vt["active_sec"].mean()) if n_vis else "-", "دقیقه:ثانیه · فقط وقتی تب باز است", GOLD2),
        ("🐢", "مشکل و کندی", n_issue, "خطا + کندی صفحه/چت", BAD if n_issue else GOOD),
    ])

    t_over, t_leads, t_vis, t_click, t_perf, t_msg = st.tabs(
        ["🏠 نمای کلی", "📞 کاربران ثبت‌شده", "👥 بازدیدکنندگان", "🖱️ کلیک‌ها", "🐢 کندی و مشکلات", "💬 پیام‌ها"])

    # ---------------------------------------------------------------- overview
    with t_over:
        a, b = st.columns([1.35, 1])
        with a:
            sec("روند روزانه", "بازدیدکننده‌ی یکتا")
            if ev.empty:
                empty("در این بازه رویدادی ثبت نشده.", "📭")
            else:
                days = ev.assign(day=ev["ts"].dt.normalize()).groupby("day")["vid"].nunique()
                days = days.reindex(pd.date_range(start, end - pd.Timedelta(days=1), freq="D"), fill_value=0)
                df = pd.DataFrame({"label": [fmt_d(d, True) for d in days.index], "count": days.values})
                bar_v(df, sort=list(df["label"]), tip="بازدیدکننده")
        with b:
            sec("قیف تبدیل", "کاربر یکتا")
            steps = [("ورود به سایت", "page_view"), ("باز کردن چت", "widget_open"), ("ارسال پیام", "chat_message"),
                     ("نمایش فرم", "form_shown"), ("شروع فرم", "form_start"), ("ثبت شماره", "lead_submitted")]
            st.html(funnel_html([(lbl, ev.loc[ev["type"] == t, "vid"].nunique()) for lbl, t in steps]))
        a, b = st.columns([1.35, 1])
        with a:
            sec("ساعت‌های پرتردد", "ورود به سایت در هر ساعت شبانه‌روز")
            pvs = ev[ev["type"] == "page_view"]
            if pvs.empty:
                empty("هنوز ورودی ثبت نشده.", "🕒")
            else:
                hrs = pvs["ts"].dt.hour.value_counts().reindex(range(24), fill_value=0).sort_index()
                bar_v(pd.DataFrame({"label": [f"{h:02d}" for h in hrs.index], "count": hrs.values}),
                      tip="ورود", color=("#5b8def", "#93c5fd"), height=200, sort=[f"{h:02d}" for h in range(24)])
        with b:
            sec("جدیدترین شماره‌ها")
            if leads.empty:
                empty("در این بازه کسی شماره ثبت نکرده.", "📞")
            else:
                html_table([{"نام": r.name, "شماره": phone_cell(r.phone), "زمان": fmt_dt(r.time)}
                            for r in leads.sort_values("time", ascending=False).head(6).itertuples()], 330)

    # ---------------------------------------------------------------- leads
    with t_leads:
        sec("کاربران ثبت‌شده", "همه‌ی کسانی که شماره داده‌اند، کنار رفتارشان در سایت")
        if leads.empty:
            empty("در این بازه کسی شماره ثبت نکرده است.", "📞")
        else:
            rows, plain = [], []
            for r in leads.sort_values("time", ascending=False).itertuples():
                m = vt.loc[r.vid] if r.vid in vt.index else None
                row = {
                    "زمان ثبت": fmt_dt(r.time), "نام": r.name, "شماره": phone_cell(r.phone), "خدمت": pill(r.service, "gold"),
                    "ورود": int(m["page_views"]) if m is not None else "-",
                    "حضور فعال (دقیقه)": fmt_dur(m["active_sec"]) if m is not None else "-",
                    "کلیک": int(m["clicks"]) if m is not None else "-",
                    "پیام": int(m["messages"]) if m is not None else "-",
                    "وضعیت": problems_pill(m["problems"]) if m is not None else pill("-", "gray"),
                    "دستگاه": device_pill(m["device"]) if m is not None else pill("-", "gray"),
                }
                rows.append(row)
                plain.append({"time": r.time, "name": r.name, "phone": r.phone, "service": r.service,
                              "visits": row["ورود"], "active_time": row["حضور فعال (دقیقه)"], "clicks": row["کلیک"], "messages": row["پیام"]})
            html_table(rows)
            st.download_button("⬇️  دانلود CSV", pd.DataFrame(plain).to_csv(index=False).encode("utf-8-sig"),
                               "leads_with_behavior.csv", "text/csv")

            sec("مسیر حرکت یک کاربر", "قدم‌به‌قدم از ورود تا ثبت شماره")
            opts = {f"{r.name} — {r.phone}": r.vid for r in leads.sort_values("time", ascending=False).itertuples()}
            pick = st.selectbox("کاربر", list(opts), label_visibility="collapsed")
            sub = ev_all[ev_all["vid"] == opts[pick]]
            if sub.empty:
                empty("برای این کاربر رویدادی ثبت نشده (احتمالاً قبل از فعال شدن ردیابی ثبت‌نام کرده).", "🔍")
            else:
                st.html(journey_html(sub))

    # ---------------------------------------------------------------- visitors
    with t_vis:
        sec("همه‌ی بازدیدکنندگان", "با شماره یا ناشناس")
        if vt.empty:
            empty("داده‌ای نیست.", "👥")
        else:
            html_table([{
                "آخرین فعالیت": fmt_dt(r.last_seen), "کاربر": phone_cell(r.phone) if r.phone else pill(f"ناشناس · {str(r.Index)[:6]}", "gray"),
                "نام": r.name, "ورود": int(r.page_views), "حضور فعال (دقیقه)": fmt_dur(r.active_sec), "کلیک": int(r.clicks),
                "پیام": int(r.messages), "وضعیت": problems_pill(r.problems), "دستگاه": device_pill(r.device)}
                for r in vt.head(300).itertuples()])
            sec("مسیر حرکت یک بازدیدکننده")
            labels = {f"{(r.phone or 'ناشناس')} · {str(r.Index)[:6]} · {fmt_dt(r.last_seen)}": r.Index for r in vt.head(300).itertuples()}
            pick = st.selectbox("بازدیدکننده", list(labels), key="vpick", label_visibility="collapsed")
            st.html(journey_html(ev_all[ev_all["vid"] == labels[pick]]))

    # ---------------------------------------------------------------- clicks
    with t_click:
        clicks = ev[ev["type"] == "click"]
        sec("بیشترین کلیک‌ها", "روی چه دکمه‌ها و لینک‌هایی بیشتر کلیک شده")
        if clicks.empty:
            empty("هنوز کلیکی ثبت نشده.", "🖱️")
        else:
            top = (clicks.assign(label=clicks["target"].map(pretty_target)).groupby("label")
                   .agg(count=("id", "count"), users=("vid", "nunique")).sort_values("count", ascending=False).head(12).reset_index())
            st.html('<div class="card">' + hbars_html([(r.label, int(r.count), f"· {int(r.users)} کاربر") for r in top.itertuples()]) + "</div>")
        sc = ev[ev["type"] == "scroll_depth"]
        sec("عمق اسکرول", "چند نفر تا کجای صفحه پایین رفته‌اند")
        if sc.empty:
            empty("داده‌ی اسکرولی ثبت نشده (اگر صفحه کوتاه است طبیعی است).", "📜")
        else:
            d = sc.groupby("value")["vid"].nunique().reindex([25, 50, 75, 100], fill_value=0)
            bar_v(pd.DataFrame({"label": [f"{int(i)}٪" for i in d.index], "count": d.values}), tip="کاربر",
                  color=("#7c3aed", "#c4b5fd"), height=200, sort=["25٪", "50٪", "75٪", "100٪"])

    # ---------------------------------------------------------------- performance & problems
    with t_perf:
        kpi_row([
            ("🚀", "میانه‌ی بارگذاری صفحه", f"{int(perf['value'].median()):,} ms" if not perf.empty else "-", "هرچه کمتر بهتر", WARN),
            ("📈", "صدک ۹۵ بارگذاری", f"{int(perf['value'].quantile(.95)):,} ms" if not perf.empty else "-", "۹۵٪ کاربران سریع‌تر از این", WARN),
            ("🤖", "پاسخ چت‌بات (میانه)", f"{int(rtt['value'].median()):,} ms" if not rtt.empty else "-", "از دید کاربر", "#a78bfa"),
            ("🧠", "پردازش مدل (میانه)", f"{int(srv['value'].median()):,} ms" if not srv.empty else "-", "سمت سرور", "#a78bfa"),
            ("🐌", "موارد کند", slow_pages + slow_chats, f"{slow_pages} صفحه · {slow_chats} پاسخ چت", BAD if slow_pages + slow_chats else GOOD),
        ])
        a, b = st.columns(2)
        with a:
            sec("روند سرعت بارگذاری صفحه", "میانه‌ی روزانه")
            if perf.empty:
                empty("هنوز داده‌ای نیست.", "🚀")
            else:
                d = perf.set_index("ts")["value"].resample("1D").median().dropna()
                line_area(pd.DataFrame({"label": [fmt_d(i, True) for i in d.index], "series": "بارگذاری صفحه", "value": d.values}),
                          colors={"بارگذاری صفحه": GOLD})
        with b:
            sec("روند سرعت پاسخ چت‌بات", "میانه‌ی ساعتی")
            if rtt.empty and srv.empty:
                empty("هنوز پیامی ارسال نشده.", "🤖")
            else:
                parts = []
                for name, s in (("کل پاسخ (کاربر)", rtt), ("پردازش مدل (سرور)", srv)):
                    if not s.empty:
                        d = s.set_index("ts")["value"].resample("1h").median().dropna()
                        parts.append(pd.DataFrame({"label": [f"{i:%H}:00\n{fmt_d(i, True)}" for i in d.index], "series": name, "value": d.values}))
                line_area(pd.concat(parts), colors={"کل پاسخ (کاربر)": INFO, "پردازش مدل (سرور)": "#a78bfa"})
                st.html('<div class="note">اگر «کل پاسخ» خیلی بیشتر از «پردازش مدل» باشد، کندی از شبکه یا سرور است، نه از Gemini.</div>')

        sec("کندترین موارد", "با شماره‌ی کاربر برای پیگیری")
        slow = pd.concat([perf[perf["value"] > slow_page_ms].assign(kind="صفحه"),
                          rtt[rtt["value"] > slow_chat_ms].assign(kind="پاسخ چت‌بات"),
                          ev[ev["type"] == "slow_resource"].assign(kind="فایل کند")])
        if slow.empty:
            empty("مورد کندی در این بازه دیده نشد. 🎉", "⚡")
        else:
            html_table([{"زمان": fmt_dt(r.ts), "نوع": pill(r.kind, "warn"), "صفحه": r.page, "هدف": r.target,
                         "مدت": Raw(f'<span dir="ltr" class="num nw" style="unicode-bidi:isolate">{int(r.value):,} ms</span>'), "کاربر": phone_cell(vid2lead["phone"].get(r.vid, ""))}
                        for r in slow.sort_values("value", ascending=False).head(50).itertuples()], 380)

        sec("خطاها و نشانه‌های مشکل")
        if problems.empty:
            empty("خطایی ثبت نشده. همه‌چیز سالم است.", "✅")
        else:
            summ = (problems.groupby(["type", "target"], dropna=False)
                    .agg(n=("id", "count"), users=("vid", "nunique"), last=("ts", "max"), sample=("detail", "last"))
                    .reset_index().sort_values("n", ascending=False))
            html_table([{"نوع": pill(LABELS.get(r.type, r.type), "bad"),
                         "هدف": pretty_target(r.target) if r.type == "rage_click" else r.target,
                         "تعداد": int(r.n), "کاربر": int(r.users), "آخرین بار": fmt_dt(r.last), "نمونه": r.sample}
                        for r in summ.itertuples()], 360)

    # ---------------------------------------------------------------- messages
    with t_msg:
        sec("سوال‌ها و پیام‌های کاربران", "جدیدترین‌ها اول؛ با نام و شماره در صورت ثبت‌نام")
        msgs = ev[ev["type"] == "chat_message"].sort_values("ts", ascending=False).head(100)
        if msgs.empty:
            empty("پیامی ثبت نشده (یا LOG_CHAT_TEXT=0 است).", "💬")
        else:
            out = []
            for r in msgs.itertuples():
                nm = vid2lead["name"].get(r.vid, "")
                ph = vid2lead["phone"].get(r.vid, "")
                who = f"<b>{esc(nm)}</b> · <span class='ph'>{esc(ph)}</span>" if ph else "<b>کاربر ناشناس</b>"
                out.append(f'<div class="bub"><div class="av">{esc((nm or "؟")[:1])}</div><div class="bd">'
                           f'<div class="meta">{who} · {esc(fmt_dt(r.ts))}</div><div class="tx">{esc(r.detail)}</div></div></div>')
            st.html("".join(out))


if auto:
    st.fragment(run_every=30)(render)()
else:
    render()
