"""Price list and marketing texts. Edit ONLY this file to change prices or wording."""

CLINIC_NAME = "نیو لایف"

# Clinic contact numbers (shown in the chat and on the page)
CLINIC_TEL = "02143662"
CLINIC_WHATSAPP = "09120993403"

# The numbers below are exactly as written on the handwritten list.
# UNIT_TOMANS = how many tomans one unit is. 1000 means 39000 -> 39,000,000 tomans (39 million).
UNIT_TOMANS = 1000

# Trust claim shown to visitors. Use a stronger wording (e.g. "تنها کلینیک ...")
# only if you can document it.
TRUST_CLAIM = "کلینیک نیو لایف دارای مجوز رسمی از وزارت بهداشت است"

# (label, low_price, high_price_or_None)
PRICES = [
    {"name": "بلفاروپلاستی (جراحی پلک)", "options": [("با جراح", 39000, None), ("با فوق‌تخصص", 49000, None)]},
    {"name": "غبغب",                      "options": [("با جراح", 39000, None), ("با فوق‌تخصص", 49000, None)]},
    {"name": "کاشت ابرو",                 "options": [("معمولی", 49000, None), ("VIP", 59000, None)]},
    {"name": "کاشت مو",                   "options": [("معمولی", 65000, None), ("VIP", 75000, None)]},
    {"name": "دایرکت ابرو",               "options": [("با جراح", 40000, None), ("با فوق‌تخصص", 45000, None)]},
    {"name": "بوکال",                     "options": [("با جراح", 30000, None), ("با فوق‌تخصص", 35000, None)]},
    {"name": "سانترال",                   "options": [("با جراح", 35000, None), ("با فوق‌تخصص", 40000, None)]},
    {"name": "لیفت شقیقه",                "options": [("با جراح", 240000, None), ("در بیمارستان", 45000, 55000)]},
    {"name": "اندوسکوپ",                  "options": [("با جراح", 230000, None), ("در بیمارستان", 45000, 55000)]},
]

_FA = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def _mil(v):
    s = f"{v * UNIT_TOMANS / 1_000_000:g}"
    return s.translate(_FA)


def _money(low, high):
    return f"{_mil(low)} تا {_mil(high)}" if high else _mil(low)


def price_lines():
    lines = []
    for item in PRICES:
        opts = " | ".join(f"{lbl}: {_money(lo, hi)}" for lbl, lo, hi in item["options"])
        lines.append(f"🔹 {item['name']} — {opts}")
    return "\n".join(lines)


def lead_message(name: str, phone: str = "") -> str:
    call = f"\n\n📞 تماس: {CLINIC_TEL}\n💬 واتساپ و ارتباط با ما: {CLINIC_WHATSAPP}"
    return (
        f"✅ {name} عزیز، درخواست شما ثبت شد و همکاران ما به‌زودی با شما تماس می‌گیرند.\n\n"
        f"🏥 {TRUST_CLAIM}؛ یعنی با خیال راحت و در محیطی معتبر درمان خود را انجام دهید.\n"
        f"✨ در {CLINIC_NAME} می‌توانید بین انجام کار توسط «جراح» یا «فوق‌تخصص» انتخاب کنید "
        f"و برای کاشت ابرو و مو، گزینه VIP هم در دسترس است.\n\n"
        f"💰 لیست قیمت خدمات (مبالغ به میلیون تومان):\n{price_lines()}\n\n"
        f"ℹ️ قیمت‌ها تقریبی است و مبلغ نهایی پس از ویزیت و بررسی شرایط شما اعلام می‌شود.\n"
        f"برای رزرو نوبت ویزیت، همین حالا پیام بدهید یا با ما تماس بگیرید.{call}"
    )


def prompt_block() -> str:
    return (
        "\n\nPRICE LIST (visitor has already registered, so you MAY quote these prices and "
        f"explain services in detail; amounts are in million tomans):\n{price_lines()}\n"
        "Rules for prices: quote ONLY numbers from this list, never invent or compute other "
        "prices, discounts or packages. Say the final price is set after an in-person visit. "
        "Services not on this list: say the team will answer personally."
    )
